"""
Author: Lindsay Burke
Date: 7/20/2023
Description: Calculator for scoring in the SAE Aero Design Competition 2023/2024
"""
from tkinter import *

#root configuration
root = Tk()
root.title("NJIT Flylanders Scoring Calculator")
canvas = Canvas()
root.geometry('350x400')
root.resizable(False, False)

#Change font/color styles here
colorSelection = "powderblue"
fontName = "Times"
root.configure(bg=colorSelection)

def calcFS():
    '''
    Calculates flight score for each flight
    '''
    global ffs, fs1, fs2, fs3, ws, wvar, w1, w2, w3
    try:
        clrError()
        setVals()
        calcWS()

        wvar = w1
        fs1 = wvar/2+setPPB() #calculates flight score for first flight

        wvar = w2
        fs2 = wvar/2+setPPB() #calculates flight score for second flight

        wvar = w3
        fs3 = wvar/2+setPPB() #calculates flight score for third flight

        ffs = fs1+fs2+fs3+ws #calculates final flight score
        outputInput.configure(state=NORMAL, fg="black")
        outputInput.insert("1.0", str(ffs)+"\n")
        outputInput.configure(state=DISABLED)
    except:
        pass

def setPPB():
    '''
    Calculates and sets payload prediction bonus
    '''
    global ppb, wvar
    temp_ppb = (5-((wvar-pPay)**2))
    if(temp_ppb<0):
        ppb = 0
    else:
        ppb = temp_ppb
    return ppb

def clrError():
    outputInput.configure(state=NORMAL)
    outputInput.delete("1.0", END)
    outputInput.configure(state=DISABLED)

def calcWS():
    global ws
    ws = 2**(1+wingspan/5)

def setVals():
    '''
    Sets values of calculation vars from input boxes
    '''
    global pPay, wingspan, w1, w2, w3, outputInput
    try:
        pPay = float(pPayInput.get())
        wingspan = float(wingspanInput.get())
        w1 = float(w1Input.get())
        w2 = float(w2Input.get())
        w3 = float(w3Input.get())
    except ValueError:
        clrError()
        outputInput.configure(state=NORMAL, fg="red")
        outputInput.insert("1.0", "Please enter numerical values only\n")
        outputInput.configure(state=DISABLED)
    except TypeError:
        clrError()
        outputInput.configure(state=NORMAL, fg="red")
        outputInput.insert("1.0", "Please enter numerical values only\n")
        outputInput.configure(state=DISABLED)

#Labels and input boxes
myLabel = Label(root, text="SAE Aero Design Scoring Calculator\n", bg=colorSelection, font=fontName+" 15 bold", justify=CENTER).grid(row=0, column=0,columnspan=4)

pPayLabel = Label(root, text="Predicted Payload", bg=colorSelection, font=fontName+" 13 bold").grid(row=1, column=2)
pPayInput = Entry(root)
pPayInput.grid(row=1, column=3,pady=5)

wingspanLabel = Label(root, text="Wingspan (ft)", bg=colorSelection, font=fontName+" 13 bold").grid(row=2, column=2)
wingspanInput = Entry(root)
wingspanInput.grid(row=2, column=3,pady=5)

w1Label = Label(root, text="Cargo Weight Flight 1", bg=colorSelection, font=fontName+" 13 bold").grid(row=3, column=2)
w1Input = Entry(root)
w1Input.grid(row=3, column=3,pady=5)

w2Label = Label(root, text="Cargo Weight Flight 2", bg=colorSelection, font=fontName+" 13 bold").grid(row=4, column=2)
w2Input = Entry(root)
w2Input.grid(row=4, column=3,pady=5)

w3Label = Label(root, text="Cargo Weight Flight 3", bg=colorSelection, font=fontName+" 13 bold").grid(row=5, column=2)
w3Input = Entry(root)
w3Input.grid(row=5, column=3,pady=5)

outputLabel = Label(root, text="Final Flight Score:", bg=colorSelection, font=fontName+" 13 bold").grid(row=9, column=2, columnspan=2, pady=(70, 0))
outputInput = Text(root, state=DISABLED, width=20, height = 3, fg="red")
outputInput.grid(row=10, column=2, columnspan=2)

startButton = Button(root, text="Calculate", command=calcFS, width=7, height=1, bg="dodgerblue", font=fontName, relief="sunken")
startButton.grid(row=6,column=2,columnspan=2, pady=(5,10))

root.mainloop()